import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  HelpCircle,
  History,
  Trash2,
  X,
  ChevronDown,
  ChevronUp,
  Sparkles,
  ShieldAlert,
  BrainCircuit,
  Check,
  Link as LinkIcon,
} from 'lucide-react';
import { AuditResult, HistoryItem, Verdict } from './types';
import { EXAMPLE_ANSWER, EXAMPLE_SOURCE, PRELOADED_EXAMPLE_RESULT } from './demoData';
import { checkAnswerAgainstSource, findExcerptSpan, isSingleUrl } from './auditPipeline';

const MAX_CHARS = 6000;
const STORAGE_KEY = 'second_opinion_history_v1';

const VERDICT_STYLES: Record<
  Verdict,
  {
    label: string;
    highlightClass: string;
    textClass: string;
    Icon: React.FC<{ className?: string }>;
  }
> = {
  correct: {
    label: 'Correct',
    highlightClass: 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-100 border-b-2 border-emerald-400',
    textClass: 'text-emerald-400',
    Icon: CheckCircle2,
  },
  wrong: {
    label: 'Wrong',
    highlightClass: 'bg-rose-500/25 hover:bg-rose-500/35 text-rose-100 border-b-2 border-rose-400',
    textClass: 'text-rose-400',
    Icon: XCircle,
  },
  'not in source': {
    label: 'Not in source',
    highlightClass: 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-100 border-b-2 border-amber-400',
    textClass: 'text-amber-400',
    Icon: AlertTriangle,
  },
  unclear: {
    label: 'Unclear',
    highlightClass: 'bg-slate-500/25 hover:bg-slate-500/35 text-slate-200 border-b-2 border-slate-400',
    textClass: 'text-slate-300',
    Icon: HelpCircle,
  },
};

export default function App() {
  const [source, setSource] = useState<string>(EXAMPLE_SOURCE);
  const [answer, setAnswer] = useState<string>(EXAMPLE_ANSWER);
  const [result, setResult] = useState<AuditResult | null>(PRELOADED_EXAMPLE_RESULT);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Collapsible fetched source text when source is a URL
  const [showFetchedSource, setShowFetchedSource] = useState<boolean>(false);

  // History side panel state
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [confirmClearAll, setConfirmClearAll] = useState<boolean>(false);

  // Refs for scrolling from a highlighted span in the AI answer to its claim card
  const claimRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const [activeClaimId, setActiveClaimId] = useState<string | null>(null);

  // Load history from localStorage on mount (wrapped in try/catch)
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          setHistory(parsed);
        }
      }
    } catch {
      // Ignore storage access errors
    }
  }, []);

  // Save updated history list to localStorage (wrapped in try/catch)
  const saveHistoryToStorage = (items: HistoryItem[]) => {
    setHistory(items);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // Ignore quota or private browsing errors
    }
  };

  // Fill both boxes with the Medicine X example and show its results immediately
  const handleTryExample = () => {
    setSource(EXAMPLE_SOURCE);
    setAnswer(EXAMPLE_ANSWER);
    setResult(PRELOADED_EXAMPLE_RESULT);
    setError(null);
    setShowFetchedSource(false);
  };

  // Run the audit end to end
  const handleCheckAnswer = async () => {
    if (!source.trim() || !answer.trim() || isLoading) return;

    if (source.length > MAX_CHARS || answer.length > MAX_CHARS) {
      setError(`Inputs are limited to ${MAX_CHARS.toLocaleString()} characters. Please shorten your text.`);
      return;
    }

    setIsLoading(true);
    setError(null);
    setLoadingStep('Checking...');

    try {
      const auditResult = await checkAnswerAgainstSource(source, answer, (msg) =>
        setLoadingStep(msg)
      );
      setResult(auditResult);
      if (auditResult.fetched_source_text) {
        setShowFetchedSource(true);
      }

      // Save to history (newest first)
      const newItem: HistoryItem = {
        id: `audit-${Date.now()}`,
        timestamp: new Date().toISOString(),
        source,
        answer,
        result: auditResult,
      };
      saveHistoryToStorage([newItem, ...history.slice(0, 49)]);
    } catch (err: any) {
      setError(err?.message || 'Something went wrong while checking the answer.');
    } finally {
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  const handleSelectHistoryItem = (item: HistoryItem) => {
    setSource(item.source);
    setAnswer(item.answer);
    setResult(item.result);
    setError(null);
    setIsHistoryOpen(false);
  };

  const handleDeleteHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = history.filter((item) => item.id !== id);
    saveHistoryToStorage(next);
  };

  const handleClearAllHistory = () => {
    saveHistoryToStorage([]);
    setConfirmClearAll(false);
  };

  // Build highlighted segments for the AI's answer using answer_excerpt
  const highlightedAnswerSegments = useMemo(() => {
    if (!result) return [];

    const spans: { start: number; end: number; claim: AuditResult['claims'][0] }[] = [];
    for (const claim of result.claims) {
      const match = findExcerptSpan(answer, claim.answer_excerpt);
      if (match && match.end > match.start) {
        spans.push({ start: match.start, end: match.end, claim });
      }
    }

    spans.sort((a, b) => a.start - b.start);

    const segments: { text: string; claim?: AuditResult['claims'][0] }[] = [];
    let cursor = 0;

    for (const s of spans) {
      const start = Math.max(cursor, s.start);
      const end = Math.min(answer.length, s.end);
      if (end <= start) continue;

      if (start > cursor) {
        segments.push({ text: answer.slice(cursor, start) });
      }
      segments.push({ text: answer.slice(start, end), claim: s.claim });
      cursor = end;
    }

    if (cursor < answer.length) {
      segments.push({ text: answer.slice(cursor) });
    }

    return segments;
  }, [answer, result]);

  const scrollToClaimCard = (claimId: string) => {
    setActiveClaimId(claimId);
    const el = claimRefs.current[claimId];
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const isInputEmpty = !source.trim() || !answer.trim();
  const isTooLong = source.length > MAX_CHARS || answer.length > MAX_CHARS;
  const sourceLooksLikeUrl = isSingleUrl(source);

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col">
      {/* Top Bar: App Name, One-line Tagline, and History Button in top right */}
      <header className="border-b border-slate-800/80 bg-[#0b0f17]/95 sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row sm:items-baseline sm:gap-3">
            <h1 className="text-xl font-bold tracking-tight text-slate-100 whitespace-nowrap">
              Second Opinion
            </h1>
            <p className="text-xs sm:text-sm text-slate-400">
              Check if an AI answer is backed by your source text.
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setConfirmClearAll(false);
              setIsHistoryOpen(true);
            }}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <History className="w-4 h-4 text-sky-400" />
            <span>History ({history.length})</span>
          </button>
        </div>
      </header>

      {/* Main Single-Page Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Top helper bar: Try an example + character limit note */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleTryExample}
            disabled={isLoading}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-sky-300 bg-sky-950/40 hover:bg-sky-900/50 border border-sky-500/30 rounded-lg transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Try an example (Medicine X)</span>
          </button>

          <span className="text-xs text-slate-400">
            Limit: up to {MAX_CHARS.toLocaleString()} characters per box
          </span>
        </div>

        {/* Two Boxes Side by Side (stacked on mobile) */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* BOX 1: SOURCE */}
          <div className="flex flex-col bg-slate-900/60 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between gap-2 mb-2">
              <label htmlFor="source-box" className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <span>Source (paste text or a link)</span>
                {sourceLooksLikeUrl && (
                  <span className="inline-flex items-center gap-1 text-xs font-normal text-sky-400">
                    <LinkIcon className="w-3 h-3" />
                    URL detected
                  </span>
                )}
              </label>
              <span
                className={`text-xs font-mono tabular-nums ${
                  source.length > MAX_CHARS ? 'text-rose-400 font-semibold' : 'text-slate-400'
                }`}
              >
                {source.length.toLocaleString()} / {MAX_CHARS.toLocaleString()}
              </span>
            </div>

            <textarea
              id="source-box"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              disabled={isLoading}
              rows={9}
              placeholder="Paste the source text or a single https:// link here..."
              className="w-full flex-1 bg-slate-950/90 border border-slate-800 focus:border-sky-500/70 focus:outline-none rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-600 leading-relaxed resize-y"
            />
          </div>

          {/* BOX 2: AI ANSWER */}
          <div className="flex flex-col bg-slate-900/60 border border-slate-800 rounded-xl p-4">
            <div className="flex items-center justify-between gap-2 mb-2">
              <label htmlFor="answer-box" className="text-sm font-semibold text-slate-200">
                AI's answer (paste the answer you want to check)
              </label>
              <span
                className={`text-xs font-mono tabular-nums ${
                  answer.length > MAX_CHARS ? 'text-rose-400 font-semibold' : 'text-slate-400'
                }`}
              >
                {answer.length.toLocaleString()} / {MAX_CHARS.toLocaleString()}
              </span>
            </div>

            <textarea
              id="answer-box"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              disabled={isLoading}
              rows={9}
              placeholder="Paste the AI-generated answer you want to check..."
              className="w-full flex-1 bg-slate-950/90 border border-slate-800 focus:border-sky-500/70 focus:outline-none rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-600 leading-relaxed resize-y"
            />
          </div>
        </div>

        {/* Collapsible Fetched Source Text Section (shown when URL was fetched) */}
        {result?.fetched_source_text && (
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
            <button
              type="button"
              onClick={() => setShowFetchedSource(!showFetchedSource)}
              className="w-full px-4 py-3 flex items-center justify-between text-left text-xs font-medium text-slate-300 hover:text-slate-100 cursor-pointer"
            >
              <span>Fetched source text (used for this audit)</span>
              {showFetchedSource ? (
                <ChevronUp className="w-4 h-4 text-slate-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-400" />
              )}
            </button>
            {showFetchedSource && (
              <div className="px-4 pb-4 pt-2 border-t border-slate-800 text-xs text-slate-300 whitespace-pre-wrap max-h-60 overflow-y-auto leading-relaxed bg-slate-950/50">
                {result.fetched_source_text}
              </div>
            )}
          </div>
        )}

        {/* Error Banner */}
        {error && (
          <div
            role="alert"
            className="p-4 rounded-xl bg-rose-950/50 border border-rose-500/40 text-sm text-rose-200 flex items-center gap-3"
          >
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* AUDIT BUTTON */}
        <div className="flex justify-center">
          <button
            type="button"
            onClick={handleCheckAnswer}
            disabled={isInputEmpty || isTooLong || isLoading}
            className="w-full sm:w-auto min-w-[240px] inline-flex items-center justify-center gap-2.5 px-6 py-3 text-sm font-semibold text-slate-950 bg-sky-400 hover:bg-sky-300 disabled:bg-slate-800 disabled:text-slate-500 rounded-xl transition-colors cursor-pointer"
          >
            {isLoading ? (
              <>
                <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>{loadingStep || 'Checking this answer...'}</span>
              </>
            ) : (
              <span>Check this answer</span>
            )}
          </button>
        </div>

        {/* RESULTS SECTION */}
        {result && (
          <section className="space-y-6 pt-4 border-t border-slate-800/80">
            {/* 1. Top Summary Card: Overall Label, Score, One-Line Summary */}
            <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2.5">
                  {result.overall_label === 'Looks reliable' && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  )}
                  {result.overall_label === 'Use with caution' && (
                    <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
                  )}
                  {result.overall_label === 'Not reliable' && (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                  <span
                    className={`text-lg font-bold ${
                      result.overall_label === 'Looks reliable'
                        ? 'text-emerald-400'
                        : result.overall_label === 'Use with caution'
                        ? 'text-amber-400'
                        : 'text-rose-400'
                    }`}
                  >
                    {result.overall_label}
                  </span>
                </div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {result.overall_summary}
                </p>
              </div>

              <div className="sm:text-right shrink-0 sm:pl-4 sm:border-l sm:border-slate-800">
                <div className="text-xs text-slate-400">Accuracy Score</div>
                <div className="text-3xl font-bold font-mono tabular-nums text-slate-100">
                  {result.score}%
                </div>
                <div className="text-xs text-slate-400 font-mono tabular-nums">
                  {result.claims.filter((c) => c.verdict === 'correct').length} of{' '}
                  {result.claims.length} claims correct
                </div>
              </div>
            </div>

            {/* 2. Highlighted AI Answer */}
            <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
                <h2 className="text-sm font-semibold text-slate-200">
                  Highlighted AI Answer (click any highlight to jump to its card)
                </h2>
                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
                  <span className="inline-flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="border-b-2 border-emerald-400">Correct</span>
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <XCircle className="w-3.5 h-3.5 text-rose-400" />
                    <span className="border-b-2 border-rose-400">Wrong</span>
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                    <span className="border-b-2 border-amber-400">Not in source</span>
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <HelpCircle className="w-3.5 h-3.5 text-slate-300" />
                    <span className="border-b-2 border-slate-400">Unclear</span>
                  </span>
                </div>
              </div>

              <div className="text-sm leading-8 text-slate-200">
                {highlightedAnswerSegments.map((seg, i) => {
                  if (!seg.claim) {
                    return <span key={i}>{seg.text}</span>;
                  }
                  const style = VERDICT_STYLES[seg.claim.verdict];
                  return (
                    <span
                      key={seg.claim.id}
                      role="button"
                      tabIndex={0}
                      onClick={() => scrollToClaimCard(seg.claim!.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          scrollToClaimCard(seg.claim!.id);
                        }
                      }}
                      className={`rounded px-1 py-0.5 mx-0.5 transition-colors cursor-pointer ${style.highlightClass}`}
                    >
                      {seg.text}
                    </span>
                  );
                })}
              </div>
            </div>

            {/* 3. Claim Cards */}
            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-slate-200">
                Claim-by-Claim Breakdown ({result.claims.length})
              </h2>

              {result.claims.map((claim, idx) => {
                const style = VERDICT_STYLES[claim.verdict];
                const VerdictIcon = style.Icon;
                const isSelected = activeClaimId === claim.id;

                return (
                  <div
                    key={claim.id}
                    ref={(el) => {
                      claimRefs.current[claim.id] = el;
                    }}
                    className={`bg-slate-900/70 border rounded-xl p-4 space-y-2.5 transition-colors ${
                      isSelected ? 'border-sky-400' : 'border-slate-800'
                    }`}
                  >
                    {/* Top row: Verdict with icon, Confidence, and Logic/Safety flags */}
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-slate-400 tabular-nums">
                          #{idx + 1}
                        </span>
                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className={`inline-flex items-center gap-1.5 font-semibold ${style.textClass}`}>
                          <VerdictIcon className="w-4 h-4 shrink-0" />
                          <span>{style.label}</span>
                        </span>

                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className="text-slate-400 font-mono">
                          Confidence: <strong className="text-slate-200">{claim.confidence}</strong>
                        </span>

                        {claim.logic_problem && (
                          <>
                            <span aria-hidden="true" className="text-slate-600">
                              ·
                            </span>
                            <span className="inline-flex items-center gap-1 font-semibold text-purple-300">
                              <BrainCircuit className="w-3.5 h-3.5" />
                              <span>Logic problem</span>
                            </span>
                          </>
                        )}

                        {claim.unsafe && (
                          <>
                            <span aria-hidden="true" className="text-slate-600">
                              ·
                            </span>
                            <span className="inline-flex items-center gap-1 font-semibold text-rose-400">
                              <ShieldAlert className="w-3.5 h-3.5" />
                              <span>Unsafe advice</span>
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* Claim text */}
                    <p className="text-sm font-semibold text-slate-100">
                      {claim.claim_text}
                    </p>

                    {/* One-sentence reason */}
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {claim.reason}
                    </p>

                    {/* Evidence quote + found/not found in source tag */}
                    {(claim.evidence_quote || claim.verdict === 'correct' || claim.verdict === 'wrong') && (
                      <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800/90 space-y-1.5 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-slate-400 font-mono text-[11px]">
                            Source evidence quote
                          </span>
                          {claim.quote_found_in_source ? (
                            <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
                              <Check className="w-3.5 h-3.5" />
                              <span>✓ found in source</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-amber-400 font-medium">
                              <AlertTriangle className="w-3.5 h-3.5" />
                              <span>⚠ Quote not found in source</span>
                            </span>
                          )}
                        </div>
                        {claim.evidence_quote ? (
                          <blockquote className="text-slate-300 italic font-mono">
                            "{claim.evidence_quote}"
                          </blockquote>
                        ) : (
                          <p className="text-slate-500 italic">No verbatim quote provided.</p>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Bottom Disclaimer Note */}
            <p className="text-xs text-slate-400 text-center pt-2">
              Confidence shows how sure the checker is, not proof. Always verify important facts.
            </p>
          </section>
        )}
      </main>

      {/* HISTORY SIDE PANEL */}
      {isHistoryOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-[#0f1522] border-l border-slate-800 h-full flex flex-col">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <History className="w-4 h-4 text-sky-400" />
                <h2 className="text-sm font-bold text-slate-100">Past Audits</h2>
              </div>
              <button
                type="button"
                onClick={() => setIsHistoryOpen(false)}
                aria-label="Close history panel"
                className="p-1.5 text-slate-400 hover:text-slate-200 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* History List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {history.length === 0 ? (
                <div className="text-center py-12 text-xs text-slate-400">
                  No past audits saved yet. Run "Check this answer" to save your first check.
                </div>
              ) : (
                history.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => handleSelectHistoryItem(item)}
                    className="p-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800/80 border border-slate-800 transition-colors cursor-pointer space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="text-slate-400 font-mono tabular-nums">
                        {new Date(item.timestamp).toLocaleString()}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => handleDeleteHistoryItem(item.id, e)}
                        aria-label="Delete history item"
                        className="p-1 text-slate-500 hover:text-rose-400 rounded cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <p className="text-xs text-slate-200 line-clamp-2">
                      {item.answer}
                    </p>

                    <div className="flex items-center gap-2 text-xs pt-1 font-mono tabular-nums">
                      <span
                        className={`font-semibold ${
                          item.result.overall_label === 'Looks reliable'
                            ? 'text-emerald-400'
                            : item.result.overall_label === 'Use with caution'
                            ? 'text-amber-400'
                            : 'text-rose-400'
                        }`}
                      >
                        {item.result.overall_label}
                      </span>
                      <span className="text-slate-600">·</span>
                      <span className="text-slate-300">{item.result.score}% correct</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Clear All History Footer with Confirmation */}
            {history.length > 0 && (
              <div className="p-4 border-t border-slate-800 bg-slate-950/60">
                {!confirmClearAll ? (
                  <button
                    type="button"
                    onClick={() => setConfirmClearAll(true)}
                    className="w-full py-2 text-xs font-medium text-rose-400 hover:text-rose-300 bg-rose-950/30 hover:bg-rose-950/50 border border-rose-500/30 rounded-lg transition-colors cursor-pointer"
                  >
                    Clear all history
                  </button>
                ) : (
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-300">Delete all saved audits?</span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setConfirmClearAll(false)}
                        className="px-3 py-1.5 text-xs text-slate-300 bg-slate-800 rounded-md cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleClearAllHistory}
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500 rounded-md cursor-pointer"
                      >
                        Confirm Clear
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
